import React from 'react';
import { Link } from 'react-router-dom';

const NavBar = () => {
  return (
    <div className='navBar flex justify-between items-center p-3rem'>
      <div className="logoDiv">
        <h1 className="logo text-25px text-blueColor">
          <strong>Over </strong>Haul
        </h1>
      </div>
      <div className="menu flex gap-8">
        <a href="/index.html" className="menuList text-[#6f6f6f] hover:text-blueColor">Jobs</a>
        <a href="/resume_aar.html" className="menuList text-[#6f6f6f] hover:text-blueColor">Resume Builder</a>
        <a href="/stack.html" className="menuList text-[#6f6f6f] hover:text-blueColor">Companies</a>
        <a href="/contact.html" className="menuList text-[#6f6f6f] hover:text-blueColor">Contact Us</a>
        <a href="/contact.html" className="menuList text-[#6f6f6f] hover:text-blueColor">About</a>
        <a href="/loginindex.html" className="menuList text-[#6f6f6f] hover:text-blueColor">Login</a>
      </div>
    </div>
  );
};

export default NavBar;
