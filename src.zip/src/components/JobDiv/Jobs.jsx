import React from 'react';
import { BiTimeFive } from 'react-icons/bi';
import logo1 from '../../Assest/logo(1).png';
import logo2 from '../../Assest/logo(2).png';
import logo3 from '../../Assest/logo(3).png';
import logo4 from '../../Assest/logo(4).png';
import logo5 from '../../Assest/logo(5).png';
import logo6 from '../../Assest/logo(6).png';
import logo7 from '../../Assest/logo(7).png';
import logo8 from '../../Assest/logo(8).png';

const Data = [
  {
    id: 1,
    image: logo1,
    title: 'Web-Developer',
    time: 'Now',
    location: 'Bangalore',
    desc: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quae, ipsum.',
    company: 'OneMedia Limited'
  },
  {
    id: 2,
    image: logo2,
    title: 'Ui-Designer',
    time: 'Now',
    location: 'Bangalore',
    desc: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quae, ipsum.',
    company: 'OCred'
  },
  {
    id: 3,
    image: logo3,
    title: 'UI/UX Designer',
    time: 'Now',
    location: 'Bangalore',
    desc: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quae, ipsum.',
    company: 'DesignCo'
  },
  {
    id: 4,
    image: logo4,
    title: 'Frontend Developer',
    time: 'Now',
    location: 'Bangalore',
    desc: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quae, ipsum.',
    company: 'CodeCrafters'
  },
  {
    id: 5,
    image: logo5,
    title: 'Graphic Designer',
    time: 'Now',
    location: 'Bangalore',
    desc: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quae, ipsum.',
    company: 'Artistry Studios'
  },
  {
     id :6,
     image :logo6,
     title :'Software Engineer',
     time :'Now',
     location :'Bangalore',
     desc :'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quae, ipsum.',
     company :'Tech Innovators'
   },
   {
     id :7,
     image :logo7,
     title :'Product Manager',
     time :'Now',
     location :'Bangalore',
     desc :'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quae, ipsum.',
     company :'Productify Inc.'
   },
   {
     id :8,
     image :logo8,
     title :'Marketing Specialist',
     time :'Now',
     location :'Bangalore',
     desc :'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quae, ipsum.',
     company :'MarketMinds'
   }
];

const Jobs = () => {
  return (
   <div className='max-w-xs mx-auto'>
      <div className='jobContainer flex flex-wrap gap-4 justify-center items-start py-8'>
        {Data.slice(0, 4).map(job => (
          <div key={job.id} className='group group/items singlejob p-6 bg-white rounded-lg hover:bg-blueColor shadow-lg'>
            <span className='flex justify-between items-center gap-2'>
              <h1 className='text-base font-semibold text-textColor'>{job.title}</h1>
              <span className='flex items-center text-[#ccc] gap-1'>
                <BiTimeFive />{job.time}
              </span>
            </span>
            <h6 className='text-[#ccc]'>{job.location}</h6>
            <p className='text-sm text-[#959595] pt-4 border-t-2 mt-4'>
              {job.desc}
            </p>
            <div className='company flex items-center gap-1 mt-4'>
              <img src={job.image} alt="company logo" className='w-6' />
              <span className='text-sm block'>{job.company}</span>
            </div>
            <button className='border-2 rounded-lg block p-2 w-full text-sm font-semibold text-textColor hover:bg-white hover:text-textColor'>
              Apply Now
            </button>
          </div>
        ))}
      </div>
      <div className='jobContainer flex flex-wrap gap-4 justify-center items-start py-8'>
        {Data.slice(4).map(job => (
          <div key={job.id} className='group group/items singlejob p-6 bg-white rounded-lg hover:bg-blueColor shadow-lg'>
            <span className='flex justify-between items-center gap-2'>
              <h1 className='text-base font-semibold text-textColor'>{job.title}</h1>
              <span className='flex items-center text-[#ccc] gap-1'>
                <BiTimeFive />{job.time}
              </span>
            </span>
            <h6 className='text-[#ccc]'>{job.location}</h6>
            <p className='text-sm text-[#959595] pt-4 border-t-2 mt-4'>
              {job.desc}
            </p>
            <div className='company flex items-center gap-1 mt-4'>
              <img src={job.image} alt="company logo" className='w-6' />
              <span className='text-sm block'>{job.company}</span>
            </div>
            <button className='border-2 rounded-lg block p-2 w-full text-sm font-semibold text-textColor hover:bg-white hover:text-textColor'>
              Apply Now
            </button>
          </div>
        ))}
      </div>
   </div>
 );
};

export default Jobs;
